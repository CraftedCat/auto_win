PRO1000 Winx64 Windows Server 2025 README
*****************************************

The driver package files in this folder can be used to install drivers
for Intel(R) Ethernet Gigabit Adapters on the following operating
systems:

* Microsoft* Windows Server* 2025

The driver package supports devices based on the following
controllers:

* Intel(R) I210 Gigabit Ethernet Controller

* Intel(R) I350 Gigabit Ethernet Controller

* Intel(R) Ethernet Connection I217

* Intel(R) Ethernet Connection I218

* Intel(R) Ethernet Connection I219
